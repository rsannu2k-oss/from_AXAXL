import os
import pandas as pd
from rapidfuzz import process, fuzz

PATH_TO_PARENT_FOLDER = 'Power BI Run Stats'


def get_list_of_files():
    files = []
    for r, d, f in os.walk(PATH_TO_PARENT_FOLDER):
        for file in f:
            files.append(os.path.join(r, file).replace('/', '\\'))
    return files


def get_list_of_all_data(list_of_reports):
    main_file = []
    for file in list_of_reports:
        df = pd.read_excel(file, index_col=None, sheet_name='UW Operational')
        main_file.append(df)
    frame = pd.concat(main_file, axis=0, ignore_index=True)
    return frame


def get_grouped_values(input_df):
    input_df['month'] = input_df['CreationDate'].dt.month_name() + ' ' + input_df['CreationDate'].dt.year.astype(
        str) + ' Users'

    list_of_users_per_month_per_report = input_df.groupby(['ReportName', 'month']).agg(
        Users=('UserId', lambda _: ', '.join(map(str, set(_)))),
        UserCount=('UserId', lambda _: int(len(set(_))))

    ).reset_index()

    final_report = list_of_users_per_month_per_report.groupby('ReportName').agg(
        All_Unique_Users=('Users', lambda x: ', '.join(set().union(*x.str.split(', ')))),
        Total_Unique_User_Count=('Users', lambda x: len(set().union(*x.str.split(', '))))
    ).reset_index()

    final_report = list_of_users_per_month_per_report.merge(final_report, on='ReportName', how='left',
                                                            suffixes=('', '_Total'))

    pivot_users = list_of_users_per_month_per_report.pivot(index='ReportName', columns='month', values='Users')
    pivot_counts = list_of_users_per_month_per_report.pivot(index='ReportName', columns='month', values='UserCount')

    pivot_counts.columns = [f"{month} Count" for month in pivot_counts.columns]

    final_df = pd.concat([pivot_users, pivot_counts], axis=1).reset_index()
    totals = final_report[['ReportName', 'All_Unique_Users', 'Total_Unique_User_Count']]

    final_df = final_df.merge(totals, on='ReportName', how='left')

    return final_df


def add_database_column(df_input):
    df_databases = pd.read_excel('ReportList_XLI_IDW_ODS3_EDS.xlsx', sheet_name='Report List',
                                 usecols=["Report Name", "Database"])

    db_report_names = df_databases['Report Name'].tolist()

    def get_best_match(name, choices, threshold=85):
        match = process.extractOne(name, choices, scorer=fuzz.token_sort_ratio)
        if match and match[1] >= threshold:
            return match[0]
        return None

    df_input['matched_report_name'] = df_input['ReportName'].apply(lambda x: get_best_match(x, db_report_names))

    df_merged = df_input.merge(
        df_databases,
        left_on='matched_report_name',
        right_on='Report Name',
        how='left',
        suffixes=('', '_db')
    )

    df_merged.drop(columns=['matched_report_name', 'Report Name'], inplace=True)

    return df_merged


def reorder_month_columns(df):
    months = ['January', 'February', 'March', 'April', 'May', 'June',
              'July', 'August', 'September', 'October', 'November', 'December']

    def sort_key(col):
        if col == 'ReportName':
            return (-1, -1, -1)
        if col == 'Database':
            return (0, 0, 0)
        for i, month in enumerate(months):
            if col.startswith(month):
                parts = col.split()
                year = int(parts[1])
                is_count = 'count' in col
                return (year, i, is_count)
        return (9999, 99, 0)

    sorted_cols = sorted(df.columns, key=sort_key)
    return df[sorted_cols]


def drop_duplicates_with_sets(df):
    df_temp = df.applymap(lambda x: tuple(sorted(x)) if isinstance(x, set) else x)
    return df.loc[~df_temp.duplicated()]


def save_to_excel(data):
    data.to_excel('PBI ReportUsageSummary.xlsx', index=False)


def run():
    list_of_files = get_list_of_files()
    main_file = get_list_of_all_data(list_of_files)
    grouped_data = get_grouped_values(main_file)
    data_with_db_name = add_database_column(grouped_data)
    data_in_proper_format = reorder_month_columns(data_with_db_name)
    correct_data = drop_duplicates_with_sets(data_in_proper_format)
    save_to_excel(correct_data)


if __name__ == "__main__":
    run()
